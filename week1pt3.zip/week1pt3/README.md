# week1pt3
