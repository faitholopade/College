#define WOKWI             // Uncomment if running on Wokwi RP2040 emulator.

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
//#include "pico/stdlib.h"
#include "pico/float.h"     // Required for using single-precision variables.
#include "pico/double.h"    // Required for using double-precision variables.


/**
 * @brief LAB02 - WALLIS.C
 *       Calculate the value of PI using the Wallis product algorithm.
 * 
 * @return int  Application return code (zero for success).
 */

float wallis_single_prec_float(int n);
double wallis_double_prec_float(int n);


int main() {

#ifndef WOKWI
    // Initialise the IO as we will be using the UART
    // Only required for hardware and not needed for Wokwi
    stdio_init_all();
#endif

    //Print the calculated value for PI (using single-precision) to the console.
    float single_prec_pi = wallis_single_prec_float(100000);
    printf("Single-precision floating point PI = %f\n", single_prec_pi);
    //Calculate the approximation error for the single-precision representation
    float single_prec_error = fabs(single_prec_pi - 3.14159265359f);
    //Print the calculated error for single-precision representation to the console.
    printf("Single-precision floating point error = %f\n", single_prec_error);

    //Print the calculated value for PI (using double-precision) to the console.
    double double_prec_pi = wallis_double_prec_float(100000);
    printf("Double-precision floating point PI = %f\n", double_prec_pi);
    //Calculate the approximation error for the double-precision representation
    double double_prec_error = fabs(double_prec_pi - 3.14159265359);
    //Print the calculated error for double-precision representation to the console.
    printf("Double-precision floating point error = %f\n", double_prec_error);

    // Returning zero indicates everything went okay.
    return 0;
}

// Create a function that implements the Wallis product algorithm, that is described in
// the introduction, using single-precision (float) floating-point representation and
// returns the calculated value for PI (use #include “pico/float.h” in your code)
float wallis_single_prec_float(int n) {
    float pi = 1.0f;
    for (int i = 1; i <= n; i++) {
        pi *= (4.0f * i * i) / (4.0f * i * i - 1.0f);
    }
    return 2.0f * pi;
}

// Create a function that implements the Wallis product algorithm, that is described in
// the introduction, using double-precision (double) floating-point representation and
// returns the calculated value for PI PI (use #include “pico/double.h” in your code).
double wallis_double_prec_float(int n) {
    double pi = 1.0;
    for (int i = 1; i <= n; i++) {
        pi *= (4.0 * i * i) / (4.0 * i * i - 1.0);
    }
    return 2.0 * pi;
}

