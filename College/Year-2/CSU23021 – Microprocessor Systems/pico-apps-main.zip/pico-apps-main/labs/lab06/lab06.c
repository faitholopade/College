#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "pico/stdlib.h"
#include "pico/float.h"     // Required for using single-precision variables.
#include "pico/double.h"    // Required for using double-precision variables.
#include "pico/multicore.h" // Required for using multiple cores on the RP2040.

/**
 * @brief This function acts as the main entry-point for core #1.
 *        A function pointer is passed in via the FIFO with one
 *        incoming int32_t used as a parameter. The function will
 *        provide an int32_t return value by pushing it back on 
 *        the FIFO, which also indicates that the result is ready.
 */
void core1_entry() {
    while (1) {

        int32_t (*func)() = (int32_t(*)()) multicore_fifo_pop_blocking();                       // Get the function pointer from the FIFO
        int32_t p = multicore_fifo_pop_blocking();                                              // Get the parameter from the FIFO       
        int32_t result = (*func)(p);                                                            // Call the function with the parameter
        multicore_fifo_push_blocking(result);                                                   // Push the result back to the FIFO (return value informing us that the result is ready)                 
    }
}

float wallis_single_prec_float(int n);
double wallis_double_prec_float(int n);

// Main code entry point for core0.
int main() {

    const int    ITER_MAX   = 100000;

    stdio_init_all();

    // Code for sequential run goes here…
    int start_time = time_us_64();                                                      // Record start time. Take snapshot of timer and store

    int single_start_time = time_us_64();                                               // Record start time. Take snapshot of timer and store
    wallis_single_prec_float(ITER_MAX);                                                 // Run the single-precision Wallis approximation
    int single_end_time = time_us_64();                                                 // Record end time. Take snapshot of timer and store
    int single_time_taken = single_end_time - single_start_time;                        // Calculate time taken for application to run in sequential mode
    
    int double_start_time = time_us_64();                                               // Record start time. Take snapshot of timer and store
    wallis_double_prec_float(ITER_MAX);                                                 // Run the double-precision Wallis approximation
    int double_end_time = time_us_64();                                                 // Record end time. Take snapshot of timer and store
    int double_time_taken = double_end_time - double_start_time;                        // Calculate time taken for application to run in sequential mode

    int end_time = time_us_64();                                                        // Record end time. Take snapshot of timer and store

    int time_taken = end_time - start_time;                                             // Calculate time taken for application to run in sequential mode

    // Display time taken for application to run in sequential mode
    printf("Single-Precision Function Execution Time (Sequential): %lld us\n", single_time_taken);
    printf("Double-Precision Function Execution Time (Sequential): %lld us\n", double_time_taken);
    printf("Total Execution Time (Sequential): %lld us\n", time_taken);


    // Code for parallel run goes here…
    multicore_launch_core1(core1_entry);                                                // Launch core 

    start_time = time_us_64();                                                          // Record start time. Take snapshot of timer and store
    
    single_start_time = time_us_64();                                                   // Record start time. Take snapshot of timer and store
    multicore_fifo_push_blocking((uintptr_t) &wallis_single_prec_float);                // Push function pointer to core1. Run the single-precision Wallis approximation on one core
    multicore_fifo_push_blocking(ITER_MAX);                                             // Push parameter to core1. Run the single-precision Wallis approximation on one core

    double_start_time = time_us_64();                                                   // Record start time. Take snapshot of timer and store
    wallis_double_prec_float(ITER_MAX);                                                 // Run the double-precision Wallis approximation on the other core
    double_end_time = time_us_64();                                                     // Record end time. Take snapshot of timer and store

    int result = multicore_fifo_pop_blocking();                                         // Wait for result from core1.
    single_end_time = time_us_64();                                                     // Record end time. Take snapshot of timer and store
    
    end_time = time_us_64();                                                            // Record end time. Take snapshot of timer and store

    single_time_taken = single_end_time - single_start_time;                            // Calculate time taken for application to run in parallel mode
    double_time_taken = double_end_time - double_start_time;                            // Calculate time taken for application to run in parallel mode
    time_taken = end_time - start_time;                                                 // Calculate time taken for application to run in parallel mode

    // Display time taken for application to run in parallel mode
    printf("\nSingle-Precision Function Execution Time (Parallel): %lld us\n", single_time_taken);
    printf("Double-Precision Function Execution Time (Parallel): %lld us\n", double_time_taken);
    printf("Total Execution Time (Parallel): %lld us\n", time_taken);

    return 0;
}


float wallis_single_prec_float(int n) {
    float pi = 1.0f;                                                           //initialize the first number in the wallis product
    for (int i = 1; i <= n; i++) {                                             //for loop to calculate the wallis product
        pi *= (4.0f * i * i) / (4.0f * i * i - 1.0f);                          //calculate the wallis product
    }
    return 2.0f * pi;                                                          //return the wallis product
}

double wallis_double_prec_float(int n) {                                       
    double pi = 1.0;                                                           //initialize the first number in the wallis product
    for (int i = 1; i <= n; i++) {                                             //for loop to calculate the wallis product
        pi *= (4.0 * i * i) / (4.0 * i * i - 1.0);                             //calculate the wallis product
    }               
    return 2.0 * pi;                                                           //return the wallis product              
}

