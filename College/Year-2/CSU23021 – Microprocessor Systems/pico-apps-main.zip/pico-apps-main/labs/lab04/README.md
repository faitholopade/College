# LAB04 NOTES

See [LAB #04](https://tcd.blackboard.com/webapps/assignment/uploadAssignment?content_id=_2127030_1&course_id=_71874_1&group_id=&mode=cpview) on the module Blackboard site for details of this lab.

To complete this lab, you will need to use the hardware lab kit that was handed out during week 3 lab sessions.
