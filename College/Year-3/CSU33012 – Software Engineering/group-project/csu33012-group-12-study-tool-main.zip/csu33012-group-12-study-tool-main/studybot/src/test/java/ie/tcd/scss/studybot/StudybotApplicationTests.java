package ie.tcd.scss.studybot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudybotApplicationTests {

	@Test
	void contextLoads() {
	}

}
