package ie.tcd.scss.countryinfo.domain;

/**
 * Gini, https://en.wikipedia.org/wiki/Gini_coefficient
 *
 * Handling of different years is not implemented.
 */
public class Gini {
    public Double _2017;
}
