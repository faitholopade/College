package ie.tcd.scss.countryinfo.domain;

import java.util.List;

public class CapitalInfo {
    private List<Double> latlng;

    public List<Double> getLatlng() {
        return latlng;
    }

    public void setLatlng(List<Double> latlng) {
        this.latlng = latlng;
    }
}
