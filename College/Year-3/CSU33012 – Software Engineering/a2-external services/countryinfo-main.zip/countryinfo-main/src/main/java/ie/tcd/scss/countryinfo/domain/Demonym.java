package ie.tcd.scss.countryinfo.domain;

public class Demonym {
    private String f;
    private String m;

    public String getF() {
        return f;
    }

    public void setF(String f) {
        this.f = f;
    }

    public String getM() {
        return m;
    }

    public void setM(String m) {
        this.m = m;
    }
}
