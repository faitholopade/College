package ie.tcd.scss.countryinfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CountryinfoApplicationTests {

    @Test
    void contextLoads() {
    }

}
