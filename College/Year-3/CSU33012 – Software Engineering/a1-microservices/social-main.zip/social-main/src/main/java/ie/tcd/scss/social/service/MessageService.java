package ie.tcd.scss.social.service;

import ie.tcd.scss.social.domain.Message;
import ie.tcd.scss.social.repo.MessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MessageService {

    @Autowired
    private MessageRepository messageRepository;

    public void createMessage(String str) {
        if (messageRepository.existsById(str)) {
            return; // do nothing if message with the same key exists
        }

        Message message = new Message();
        message.setMessageKey(str);
        message.setTitle(str.repeat(5));
        message.setBody(str.repeat(10));

        messageRepository.save(message);
    }
}
