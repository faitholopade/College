package ie.tcd.scss.namelist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NamelistApplication {

	public static void main(String[] args) {
		SpringApplication.run(NamelistApplication.class, args);
	}

}
