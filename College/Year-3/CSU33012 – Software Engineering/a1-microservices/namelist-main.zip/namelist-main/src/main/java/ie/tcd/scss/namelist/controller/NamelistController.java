package ie.tcd.scss.namelist.controller;

import ie.tcd.scss.namelist.NameDto;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
public class NamelistController {

    private final List<String> names = new ArrayList<>();

    @GetMapping("/reset")
    public ResponseEntity<String> resetNames() {
        names.clear();
        return ResponseEntity.ok().body("Names list reset successfully");
    }
    @PostMapping("/names")
    public ResponseEntity<String> addName(@RequestBody NameDto nameDto) {
        String name = nameDto.getName();
        if (name == null || name.trim().isEmpty()) {
            return ResponseEntity.status(403).body("Empty names are not allowed and rejected.");
        }
        if (!names.contains(name)) {
            names.add(name);
            return ResponseEntity.status(201).body("Name stored successfully");
        }
        return ResponseEntity.status(200).body("Name already exists in the list");
    }

    @GetMapping("/names")
    public ResponseEntity<String> getNames() {
        if (names.isEmpty()) {
            return ResponseEntity.ok().body("(List of names is empty)");
        }
        String sortedNames = names.stream().sorted().collect(Collectors.joining(", "));
        return ResponseEntity.ok().body(sortedNames);
    }
}