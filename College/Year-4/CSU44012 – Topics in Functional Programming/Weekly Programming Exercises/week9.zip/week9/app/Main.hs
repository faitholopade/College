module Main where

import InterpreterBase

main :: IO ()
main = runSample
