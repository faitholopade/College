module Main where

import Render

main :: IO ()
main = renderMandelbrot "mandelbrot.png"
